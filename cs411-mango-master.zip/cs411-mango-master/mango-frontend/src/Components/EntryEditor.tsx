import React from 'react';
import {connect, ConnectedProps} from 'react-redux';
import {AppState, EntryType, Entry, EntryIdentifier} from '../store/types';
import {Button, Form, FormControl, Jumbotron, Container, Row, Col, InputGroup} from 'react-bootstrap';
import {
  cancelModifyEntry as cancelModifyEntryPredispatch, 
  modifyEntry as modifyEntryPredispatch,
  deleteEntry as deleteEntryPredispatch} from '../store/actions'

const mapState = (state: AppState) => (
  {
    entryIdentifier: state.entryBeingModified!,
    entriesOfType: (state.entryBeingModified!.type === EntryType.DRUG) ? 
      state.userEntries!.drugs : state.userEntries!.procedures,
    user: state.user!
  }
)

const mapDispatch = {
  cancelModifyEntry : () => cancelModifyEntryPredispatch(),
  modifyEntry : (entryIdent: EntryIdentifier, newEntry: Entry, user : string) => 
    modifyEntryPredispatch(entryIdent, newEntry, user),
  deleteEntry : (entryIdent: EntryIdentifier, entryIdNum:number, user: string) =>
    deleteEntryPredispatch(entryIdent, entryIdNum, user)
}

const connector = connect(mapState, mapDispatch)

type EntryEditorProps = ConnectedProps<typeof connector>

interface EntryEditorState {
  nameInput: string,
  costInput: string,
  hasInsuranceInput: boolean,
  zipcodeInput: string
  entryId: number
}

class EntryEditor extends React.Component<EntryEditorProps, EntryEditorState>{

  constructor(props : EntryEditorProps){
    super(props);

    let initEntry : Entry;

    if(props.entryIdentifier!.index > -1){
      initEntry = props.entriesOfType[props.entryIdentifier!.index];
    } else {
      initEntry = {
        name: "",
        cost: 0,
        hasInsurance: false,
        zipcode: "",
        id: -1
      }
    }

    this.state ={
      nameInput: initEntry.name,
      costInput: initEntry.cost.toString(),
      hasInsuranceInput: initEntry.hasInsurance,
      zipcodeInput: initEntry.zipcode,
      entryId: initEntry.id
    }
  }

  chooseTitle = () => {
    if(this.props.entryIdentifier.index === -1){
      var action = 'Insert'
    } else {
      var action = 'Update'
    }

    if(this.props.entryIdentifier.type === EntryType.DRUG){
      var item = 'Drug';
    } else {
      var item = 'Procedure';
    }

    return action + ' ' + item;
  }

  modifyName = (e : any) => {
    this.setState({nameInput: e.target.value})
  }

  modifyCost = (e : any) => {
    this.setState({costInput: e.target.value})
  }

  modifyInsurance = (e :any) => {
    this.setState({hasInsuranceInput : e.target.checked})
  }

  modifyZipcode = (e :any) => {
    this.setState({zipcodeInput : e.target.value})
  }

  handleDeleteEntry = () => {
    let idNum = this.props.entriesOfType[this.props.entryIdentifier.index].id;
    this.props.deleteEntry(this.props.entryIdentifier, idNum, this.props.user);
  }

  validateAndSubmit = () => {
    let newEntry : Entry = {
      name: this.state.nameInput,
      cost: parseFloat(this.state.costInput),
      hasInsurance: this.state.hasInsuranceInput,
      zipcode: this.state.zipcodeInput,
      id: (this.props.entryIdentifier.index === -1) ? -1 : this.props.entriesOfType[this.props.entryIdentifier.index].id
    }

    this.props.modifyEntry(this.props.entryIdentifier, newEntry, this.props.user);
  }

  render() {

    let {entryIdentifier} = this.props;
    
    return (
      <div className='entryeditor'>
        <Container>
          <Jumbotron>
            <h1>{this.chooseTitle()}</h1>
            <Form onSubmit={this.validateAndSubmit}>
              <Row>
                <Col>
                  <InputGroup>
                    <InputGroup.Prepend>
                      <InputGroup.Text>
                        Name
                      </InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl defaultValue={this.state.nameInput} onChange={this.modifyName}/>
                  </InputGroup>                 
                </Col>
              </Row>
              <Row>
                <Col>
                  <InputGroup>
                    <InputGroup.Prepend>
                      <InputGroup.Text>
                        Cost
                      </InputGroup.Text>
                      <InputGroup.Text>
                        $
                      </InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl defaultValue={this.state.costInput} onChange={this.modifyCost}/>
                  </InputGroup>
                </Col>
                <Col>
                  <InputGroup>
                    <InputGroup.Prepend>
                      <InputGroup.Text>
                        Zipcode
                      </InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl defaultValue={this.state.zipcodeInput} onChange={this.modifyZipcode}/>
                  </InputGroup>
                </Col> 
                <Col>
                   <Form.Check defaultChecked={this.state.hasInsuranceInput} onChange={this.modifyInsurance} label="With Insurance?" />
                </Col>
              </Row>
              <Row>
                <Col>
                  <Button type="submit" style={{marginRight: 10}}>Submit</Button>
                  {
                    entryIdentifier.index !== -1 && 
                    <Button 
                      style={{marginRight: 10}} 
                      variant="danger" 
                      onClick={this.handleDeleteEntry}>
                      Delete
                    </Button>
                  }
                  <Button onClick={this.props.cancelModifyEntry}>Cancel</Button>
                </Col>
              </Row>
            </Form>        
          </Jumbotron>
        </Container>
      </div>
    )
  }
}

export default connector(EntryEditor);