import React from 'react';
import {FormControl, Button, Jumbotron, Container} from 'react-bootstrap';
import {connect, ConnectedProps} from 'react-redux';
import {AppState} from '../store/types';
import {fetchRemedies} from '../store/actions';

const mapStateToProps = (state : AppState) => (
  {
    isFetchingRemedies: state.isFetchingRemedies,
    remedies: state.remedies
  }
)

const mapDispatchToProps = {
  getRemedies: (malady: string) => fetchRemedies(malady),
}

const connector = connect(mapStateToProps, mapDispatchToProps);

type SearchPageProps = ConnectedProps<typeof connector>;

class SearchPage extends React.Component<SearchPageProps>{

  renderSearchResultsComponents = () => {

  }

  render(){
    return(
      <div>
        <Container>
          <Jumbotron>        
            <h1>How Much To Fix Me?</h1>
            <FormControl
              placeholder="Affliction"
            />
            <Button onClick={() => this.props.getRemedies("malady")}>
              Search
            </Button>
            {
              this.props.isFetchingRemedies && <h1>Fetching</h1>
            }
            <h2>{JSON.stringify(this.props.remedies)}</h2>
          </Jumbotron>
        </Container>

      </div>
    )
  }
}

export default connector(SearchPage);