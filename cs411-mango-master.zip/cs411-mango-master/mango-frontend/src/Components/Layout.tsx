import React from 'react';
import Body from './Body';
import Header from './Header';

class Layout extends React.Component{
    render(){
        return (
            <div className="layout">
                <div>
                    <Header/>
                </div>
                <div>
                    <Body />
                </div> 
            </div>

        );
    }
}

export default Layout;