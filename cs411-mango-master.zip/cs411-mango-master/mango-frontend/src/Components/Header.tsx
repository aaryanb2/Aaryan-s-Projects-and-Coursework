import React from 'react';
import {Navbar, Nav, Button} from 'react-bootstrap'
import {switchPage as switchPagePredispatch,
        signOut as signOutPredispatch} from '../store/actions';
import {connect, ConnectedProps} from 'react-redux'
import {AppState} from '../store/types';
import './styles/Header.css'

const mapState = (state: AppState) => (
  {
    user : state.user
  }
)

const mapDispatch = {
  switchPage: (page: number) => switchPagePredispatch(page),
  signOut: () => signOutPredispatch()
}

const connector = connect(mapState, mapDispatch);

type HeaderProps = ConnectedProps<typeof connector>;

class Header extends React.Component<HeaderProps>{

  render() {

    let {switchPage, signOut, user} = this.props;

    return (
      <div className="header">
        <Navbar bg="dark" variant="dark">
          <Navbar.Brand>
            <img 
              src='./mango.ico' 
              alt='mango'
              width={30}
              height={30} />
            Team Mango
          </Navbar.Brand>
          <Navbar.Collapse>
            <Nav>
              <Nav.Link href="#home" onSelect={() => {switchPage(0)}}>Home</Nav.Link>
              <Nav.Link href="#user" onSelect={() => {switchPage(1)}}>User</Nav.Link>
            </Nav>
            <div className="ml-auto">
            {
              user === undefined ?
              (
                <Navbar.Text>
                  {"Not signed in"}
                </Navbar.Text>
              ) :
              (
                <React.Fragment>                
                  <Navbar.Text style={{marginRight: 10}}>
                    {"Signed in as: " + user}
                  </Navbar.Text>
                  <Button variant='outline-secondary' onClick={signOut}>
                    Sign out
                  </Button>
                </React.Fragment>
              )
            }
            </div>
          </Navbar.Collapse>
        </Navbar>
      </div>
    )
  }
}

export default connector(Header);