import { 
  SWITCH_PAGE,
  REQUEST_REMEDIES,
  RECEIVE_REMEDIES,
  REQUEST_SIGN_IN,
  RECEIVE_SIGN_IN,
  SIGN_OUT,
  BEGIN_MODIFY_ENTRY,
  CANCEL_MODIFY_ENTRY,
  SUBMIT_MODIFICATION,
  RECEIVE_MODIFICATION_SUCCESS
} from "./actionTypes";

export interface AppState {
  user: string | undefined;
  isSigningIn: boolean;
  userEntries: EntriesObj | undefined;
  entryBeingModified: EntryIdentifier | undefined;
  modificationBeingSubmitted: boolean;
  isFetchingRemedies : boolean;
  remedies: Object | undefined;
  page: number;
  message: string;
}

export interface EntriesObj{
  drugs: Array<Entry>;
  procedures: Array<Entry>;
}

export enum EntryType {
  DRUG = 'DRUG',
  PROCEDURE = 'PROCEDURE'
}

export interface EntryIdentifier {
  type: EntryType,
  index: number,
}

export interface Entry {
  name: string;
  cost: number;
  hasInsurance: boolean;
  zipcode: string
  id: number
}

export interface EntriesResponse {
  user: string;
  status: string;
  entries: {
    [key: string] : Array<Entry>
  }
}

interface RequestRemedies {
  type: typeof REQUEST_REMEDIES;
  payload: string;
}

interface ReceiveRemedies {
  type: typeof RECEIVE_REMEDIES;
  payload: Object;
}

interface SwitchPage{
  type: typeof SWITCH_PAGE;
  page: number;
}

interface RequestSignIn{
  type: typeof REQUEST_SIGN_IN;
  user: string;
}

interface ReceiveSignIn{
  type: typeof RECEIVE_SIGN_IN;
  user: string;
  payload: EntriesResponse;
}

interface SignOut{
  type: typeof SIGN_OUT;
}

interface BeginModifyEntry{
  type: typeof BEGIN_MODIFY_ENTRY;
  entryIdentifier: EntryIdentifier;
}

interface CancelModifyEntry{
  type: typeof CANCEL_MODIFY_ENTRY;
}

interface SubmitModification{
  type: typeof SUBMIT_MODIFICATION;
  entryIdent: EntryIdentifier;
  newEntry: Entry | null;
}

interface ReceiveModficationSuccess{
  type: typeof RECEIVE_MODIFICATION_SUCCESS;
  entryIdent: EntryIdentifier;
  newEntry: Entry | null;
}


export type ActionObjectTypes = 
  SwitchPage | 
  RequestRemedies | 
  ReceiveRemedies | 
  RequestSignIn | 
  ReceiveSignIn | 
  SignOut | 
  BeginModifyEntry | 
  CancelModifyEntry |
  SubmitModification |
  ReceiveModficationSuccess;


