import {ActionObjectTypes, EntriesResponse, EntryType, EntryIdentifier, Entry} from './types';
import { REQUEST_SIGN_IN, SWITCH_PAGE, REQUEST_REMEDIES, RECEIVE_REMEDIES, RECEIVE_SIGN_IN, SIGN_OUT, BEGIN_MODIFY_ENTRY, CANCEL_MODIFY_ENTRY, SUBMIT_MODIFICATION, RECEIVE_MODIFICATION_SUCCESS} from "./actionTypes";

export const requestRemedies = (payload: string) : ActionObjectTypes => (
  {
    type: REQUEST_REMEDIES,
    payload: payload
  });

export const receiveRemedies = (payload: Object) : ActionObjectTypes => (
  {
    type: RECEIVE_REMEDIES,
    payload: payload
  })

export const switchPage = (newPage: number) : ActionObjectTypes => (
  {
    type: SWITCH_PAGE,
    page: newPage
  })

export function fetchRemedies(malady : string) {
  
  return function (dispatch : any /* let redux-thunk handle this */) {
    dispatch(requestRemedies(malady));
    return fetch("./fakeremedies.json")
      .then(response => response.json())
      .then( json => dispatch(receiveRemedies(json)))
  }
}

export const requestSignIn = (username: string) : ActionObjectTypes => (
  {
    type: REQUEST_SIGN_IN,
    user: username
  })

export const receiveSignIn = (user:string, payload: EntriesResponse) : ActionObjectTypes => (
  {
    type: RECEIVE_SIGN_IN,
    user: user,
    payload: payload
  }
)

export function signIn(user: string) {

  return function(dispatch: any /* let redux-thunk handle this */){
    dispatch(requestSignIn(user));
    return fetch("http://localhost:8080/getrecords?username=" + user)
      .then(response => response.json())
      .then(json => dispatch(receiveSignIn(user, json)))
  }
}

export const signOut = () : ActionObjectTypes => (
  {
    type: SIGN_OUT 
 });

 export const beginModifyEntry = (entryType : EntryType, index : number) : ActionObjectTypes => (
   {
      type: BEGIN_MODIFY_ENTRY,
      entryIdentifier: {
        type: entryType,
        index: index
      }
   }
 )

 export const cancelModifyEntry = () : ActionObjectTypes => (
   {
     type: CANCEL_MODIFY_ENTRY
   }
 )

 export const submitModification = (entryIdent : EntryIdentifier, newEntry : Entry | null) => (
   {
    type: SUBMIT_MODIFICATION,
    entryIdent: entryIdent,
    newEntry : newEntry
   }
 )

 export const receiveModificationSuccess = (entryIdent : EntryIdentifier, newEntry : Entry | null) => (
   {
    type: RECEIVE_MODIFICATION_SUCCESS,
    entryIdent: entryIdent,
    newEntry: newEntry
   }
 )

 export function deleteEntry(entryIdent : EntryIdentifier, entryIdNum: number, user: string) {
  return function(dispatch : any /** Let redux-thunk handle this */) {

    dispatch(submitModification(entryIdent, null));

    let entryTypeParam = (entryIdent.type === EntryType.DRUG) ? 'type=d' : 'type=p';
    let userParam = 'username=' + user;
    let idParam = 'recordID=' + entryIdNum.toString();
    fetch('http://localhost:8080/delete?' + entryTypeParam + '&' + userParam + '&' + idParam)
      .then(response => response.json())
      .then(json => dispatch(receiveModificationSuccess(entryIdent, null))) 
  }
 }

 export function modifyEntry(entryIdent: EntryIdentifier, newEntry: Entry, user: string) {

  return function(dispatch : any /** Let redux-thunk handle this */) {

    dispatch(submitModification(entryIdent, newEntry));

    let entryTypeParam = (entryIdent.type === EntryType.DRUG) ? 'type=d' : 'type=p';

    if (entryIdent.index === -1) {
      /** Insert */
      let userParam = 'username=' + user;
      let nameParam = 'name=' + newEntry.name;
      let costParam = 'cost=' + newEntry.cost;
      let zipcodeParam = 'zipcode=' + newEntry.zipcode;
      let insuranceParam = 'ins='+ newEntry.hasInsurance;
      fetch('http://localhost:8080/addrecord?' + userParam + '&' + nameParam + '&' + costParam + '&' + zipcodeParam + '&' + insuranceParam + '&' + entryTypeParam)
        .then(response => response.json())
        .then(json => {
          newEntry.id=json.id;
          dispatch(receiveModificationSuccess(entryIdent, newEntry));
        })
    } else {
      /** Update */
      let userParam = 'username=' + user;
      let nameParam = 'name=' + newEntry.name;
      let costParam = 'cost=' + newEntry.cost;
      let zipcodeParam = 'zipcode=' + newEntry.zipcode;
      let insuranceParam = 'ins='+ newEntry.hasInsurance;
      let idParam = 'recordID=' + newEntry.id;
      fetch('http://localhost:8080/update?' + userParam + '&' + nameParam + '&' + costParam + '&' + zipcodeParam + '&' + insuranceParam + '&' + entryTypeParam + '&' + idParam)
        .then(response => response.json())
        .then(json => dispatch(receiveModificationSuccess(entryIdent, newEntry)))
    }
  }

 }
