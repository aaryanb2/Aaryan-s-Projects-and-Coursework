import {Entry, ActionObjectTypes, AppState, EntryIdentifier, EntryType} from './types';
import { SIGN_OUT, REQUEST_SIGN_IN, REQUEST_REMEDIES, RECEIVE_REMEDIES, SWITCH_PAGE, RECEIVE_SIGN_IN, BEGIN_MODIFY_ENTRY, CANCEL_MODIFY_ENTRY, SUBMIT_MODIFICATION, RECEIVE_MODIFICATION_SUCCESS } from "./actionTypes";
import {combineReducers} from 'redux';

const initialState : AppState = { 
  user:undefined, 
  isSigningIn: false,
  userEntries: undefined,
  entryBeingModified: undefined,
  modificationBeingSubmitted: false,
  isFetchingRemedies: false,
  remedies: undefined,
  page: 1, 
  message: "no message"
}

const bigNastyReduceFunction = (state : AppState= initialState, action : ActionObjectTypes) : AppState => {
  switch(action.type) {
    case REQUEST_REMEDIES: 
      return Object.assign({}, state, {isFetchingRemedies: true})
    case RECEIVE_REMEDIES:
      return Object.assign({}, state, {isFetchingRemedies: false, remedies: action.payload})
    case SWITCH_PAGE:
      return Object.assign({}, state, {page: action.page})
    case REQUEST_SIGN_IN:
      return Object.assign({}, state, {isSigningIn: true})
    case RECEIVE_SIGN_IN:
      return Object.assign({}, state, {user: action.user, isSigningIn: false, userEntries: action.payload.entries})
    case SIGN_OUT:
      return Object.assign({}, state, {user: undefined, signInResponse: undefined})
    case BEGIN_MODIFY_ENTRY:
      return Object.assign({}, state, {entryBeingModified: action.entryIdentifier})
    case CANCEL_MODIFY_ENTRY:
      return Object.assign({}, state, {entryBeingModified: undefined})
    case SUBMIT_MODIFICATION:
      return Object.assign({}, state, {modificationBeingSubmitted: true})
    case RECEIVE_MODIFICATION_SUCCESS:
      let newState = Object.assign({}, state, {entryBeingModified: undefined, modificationBeingSubmitted: false})
      /** Delete */
      if(action.newEntry === null){
        if(action.entryIdent.type === EntryType.DRUG){
          newState.userEntries!.drugs = newState.userEntries!.drugs.filter( 
            (_ : Entry, index:number) => (index !== action.entryIdent.index))
        } else {
            newState.userEntries!.procedures = newState.userEntries!.procedures.filter( 
            (_ : Entry, index:number) => (index !== action.entryIdent.index))
        }
      } /** Insertion */
      else if (action.entryIdent.index === -1) {
        if(action.entryIdent.type === EntryType.DRUG){
          newState.userEntries!.drugs.push(action.newEntry);
        } else {
          newState.userEntries!.procedures.push(action.newEntry);
        }
      } /** Update */
      else {
        if(action.entryIdent.type === EntryType.DRUG){
          newState.userEntries!.drugs = newState.userEntries!.drugs.map( (entry : Entry, index: number) => {
            if(index === action.entryIdent.index){
              return action.newEntry!;
            } else {
              return entry;
            }
          })
        } else {
          newState.userEntries!.procedures = newState.userEntries!.procedures.map( (entry : Entry, index: number) => {
            if(index === action.entryIdent.index){
              return action.newEntry!;
            } else {
              return entry;
            }
          })
        }
      }
      return newState;
    default:
      return state
  }
}

export default bigNastyReduceFunction;